package @@PACKAGE@@;

/**
 * <<Class summary>>
 *
 * @author @@AUTHOR@@
 * @version $Rev$
 */
public interface @@CLASSNAME@@ {
    /** Version control identifier strings. */
    public static final String[] RCS_ID = {
        "$URL: http://telly/svn/repos/TextMate/trunk/Bundles/Java.tmbundle/Templates/Java%20Source/java-insert.java $",
        "$Id$",
    };
    
}

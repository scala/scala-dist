package @@PACKAGE@@;

/**
 * <<Class summary>>
 *
 * @author @@AUTHOR@@
 * @version $Rev$
 */
public final class @@CLASSNAME@@ {
    /** Version control identifier strings. */
    public static final String[] RCS_ID = {
        "$URL: http://macromates.com/svn/Bundles/trunk/Bundles/Java.tmbundle/Templates/Java Class/class-insert.java $",
        "$Id$",
    };
    
	// {{{ @@CLASSNAME@@ constructor
    /**
     * 
     */
    public @@CLASSNAME@@() {
        
    }
	// }}}
}

package foo;

/**
 * <<Class summary>>
 *
 * @author   &lt;&gt;
 * @version $Rev$
 */
public final class Test {
    /** Version control identifier strings. */
    public static final String[] RCS_ID = {
        "$URL: http://macromates.com/svn/Bundles/trunk/Bundles/Java.tmbundle/Templates/Java%20Class/class-insert.java $",
        "$Id$",
    };
    
    class Bar {
        Bar() {
            System.out.println("in Bar");
        }
        
        void doFoo() {
            
        };
    };
    
	// {{{ Test constructor
    /**
     * 
     */
    public Test() {
        boolean b = true;
    }
	// }}}
	
	// {{{ getFoo
	/**
	 * Returns foo.
	 *
	 * @return the value of Foo.
	 */
	String getFoo() {
	    if (true) {
	        
	    }
	}
	// }}}

    void setFoo() {
        
    }
    // {{{ x
    /**
     * z
     */
    public Ya xz() {
        
    }
    // }}}
    
}
